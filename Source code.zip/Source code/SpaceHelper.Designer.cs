﻿namespace SpacemeshHelper
{
    partial class SpaceHelper
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            panel1 = new Panel();
            checkBox4 = new CheckBox();
            panel4 = new Panel();
            linkLabel5 = new LinkLabel();
            linkLabel4 = new LinkLabel();
            textBox3 = new TextBox();
            label12 = new Label();
            label11 = new Label();
            label18 = new Label();
            label17 = new Label();
            label16 = new Label();
            label10 = new Label();
            label9 = new Label();
            checkBox2 = new CheckBox();
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            checkBox5 = new CheckBox();
            panel5 = new Panel();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            label21 = new Label();
            label22 = new Label();
            label23 = new Label();
            label24 = new Label();
            label25 = new Label();
            label26 = new Label();
            panel2 = new Panel();
            checkBox1 = new CheckBox();
            listBox1 = new ListBox();
            button1 = new Button();
            comboBox2 = new ComboBox();
            listBox2 = new ListBox();
            comboBox1 = new ComboBox();
            linkLabel1 = new LinkLabel();
            linkLabel3 = new LinkLabel();
            linkLabel2 = new LinkLabel();
            textBox2 = new TextBox();
            label1 = new Label();
            textBox1 = new TextBox();
            label3 = new Label();
            label6 = new Label();
            label2 = new Label();
            label8 = new Label();
            label5 = new Label();
            label4 = new Label();
            label7 = new Label();
            flowLayoutPanel1 = new FlowLayoutPanel();
            richTextBox1 = new RichTextBox();
            button2 = new Button();
            tabPage2 = new TabPage();
            panel6 = new Panel();
            textBox6 = new TextBox();
            textBox5 = new TextBox();
            textBox4 = new TextBox();
            label28 = new Label();
            label27 = new Label();
            label20 = new Label();
            panel3 = new Panel();
            label39 = new Label();
            label34 = new Label();
            label38 = new Label();
            label35 = new Label();
            label37 = new Label();
            label36 = new Label();
            checkBox3 = new CheckBox();
            flowLayoutPanel2 = new FlowLayoutPanel();
            button5 = new Button();
            listBox3 = new ListBox();
            contextMenuStrip1 = new ContextMenuStrip(components);
            addDiskDirToolStripMenuItem = new ToolStripMenuItem();
            removeDirToolStripMenuItem = new ToolStripMenuItem();
            label19 = new Label();
            folderBrowserDialog1 = new FolderBrowserDialog();
            folderBrowserDialog2 = new FolderBrowserDialog();
            panel1.SuspendLayout();
            panel4.SuspendLayout();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            panel5.SuspendLayout();
            panel2.SuspendLayout();
            tabPage2.SuspendLayout();
            panel6.SuspendLayout();
            panel3.SuspendLayout();
            contextMenuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(checkBox4);
            panel1.Controls.Add(panel4);
            panel1.Controls.Add(checkBox2);
            panel1.Controls.Add(tabControl1);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(949, 743);
            panel1.TabIndex = 0;
            // 
            // checkBox4
            // 
            checkBox4.AutoSize = true;
            checkBox4.Location = new Point(780, 41);
            checkBox4.Name = "checkBox4";
            checkBox4.Size = new Size(132, 21);
            checkBox4.TabIndex = 11;
            checkBox4.Text = "Go-space autorun";
            checkBox4.UseVisualStyleBackColor = true;
            checkBox4.CheckedChanged += checkBox4_CheckedChanged;
            // 
            // panel4
            // 
            panel4.Controls.Add(linkLabel5);
            panel4.Controls.Add(linkLabel4);
            panel4.Controls.Add(textBox3);
            panel4.Controls.Add(label12);
            panel4.Controls.Add(label11);
            panel4.Controls.Add(label18);
            panel4.Controls.Add(label17);
            panel4.Controls.Add(label16);
            panel4.Controls.Add(label10);
            panel4.Controls.Add(label9);
            panel4.Location = new Point(3, 3);
            panel4.Name = "panel4";
            panel4.Size = new Size(759, 70);
            panel4.TabIndex = 1;
            // 
            // linkLabel5
            // 
            linkLabel5.AutoSize = true;
            linkLabel5.Location = new Point(296, 41);
            linkLabel5.Name = "linkLabel5";
            linkLabel5.Size = new Size(52, 17);
            linkLabel5.TabIndex = 4;
            linkLabel5.TabStop = true;
            linkLabel5.Text = "Refresh";
            linkLabel5.LinkClicked += linkLabel5_LinkClicked;
            // 
            // linkLabel4
            // 
            linkLabel4.AutoSize = true;
            linkLabel4.Location = new Point(296, 13);
            linkLabel4.Name = "linkLabel4";
            linkLabel4.Size = new Size(52, 17);
            linkLabel4.TabIndex = 4;
            linkLabel4.TabStop = true;
            linkLabel4.Text = "Refresh";
            linkLabel4.LinkClicked += linkLabel4_LinkClicked;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(562, 10);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(108, 23);
            textBox3.TabIndex = 2;
            textBox3.Text = "127.0.0.1:9092";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(429, 13);
            label12.Name = "label12";
            label12.Size = new Size(127, 17);
            label12.TabIndex = 1;
            label12.Text = "SpaceMesh SERVER:";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(58, 41);
            label11.Name = "label11";
            label11.Size = new Size(71, 17);
            label11.TabIndex = 0;
            label11.Text = "postcli ver:";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(187, 41);
            label18.Name = "label18";
            label18.Size = new Size(51, 17);
            label18.TabIndex = 0;
            label18.Text = "LastVer";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(187, 13);
            label17.Name = "label17";
            label17.Size = new Size(51, 17);
            label17.TabIndex = 0;
            label17.Text = "LastVer";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(130, 13);
            label16.Name = "label16";
            label16.Size = new Size(35, 17);
            label16.TabIndex = 0;
            label16.Text = "0.0.0";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(130, 41);
            label10.Name = "label10";
            label10.Size = new Size(35, 17);
            label10.TabIndex = 0;
            label10.Text = "0.0.0";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(9, 13);
            label9.Name = "label9";
            label9.Size = new Size(120, 17);
            label9.TabIndex = 0;
            label9.Text = "Go-spacemesh ver:";
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Location = new Point(780, 16);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(115, 21);
            checkBox2.TabIndex = 11;
            checkBox2.Text = "PostCli autorun";
            checkBox2.UseVisualStyleBackColor = true;
            checkBox2.CheckedChanged += checkBox2_CheckedChanged;
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Location = new Point(0, 74);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(952, 666);
            tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(checkBox5);
            tabPage1.Controls.Add(panel5);
            tabPage1.Controls.Add(panel2);
            tabPage1.Controls.Add(flowLayoutPanel1);
            tabPage1.Controls.Add(richTextBox1);
            tabPage1.Controls.Add(button2);
            tabPage1.Location = new Point(4, 26);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(944, 636);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Multiple Graphics Makefiles";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            checkBox5.AutoSize = true;
            checkBox5.Checked = true;
            checkBox5.CheckState = CheckState.Checked;
            checkBox5.Location = new Point(412, 539);
            checkBox5.Name = "checkBox5";
            checkBox5.Size = new Size(313, 21);
            checkBox5.TabIndex = 10;
            checkBox5.Text = "Automatically add to Go-space upon completion.";
            checkBox5.UseVisualStyleBackColor = true;
            // 
            // panel5
            // 
            panel5.BackColor = Color.DarkGray;
            panel5.Controls.Add(label13);
            panel5.Controls.Add(label14);
            panel5.Controls.Add(label15);
            panel5.Controls.Add(label21);
            panel5.Controls.Add(label22);
            panel5.Controls.Add(label23);
            panel5.Controls.Add(label24);
            panel5.Controls.Add(label25);
            panel5.Controls.Add(label26);
            panel5.Location = new Point(6, 227);
            panel5.Name = "panel5";
            panel5.Size = new Size(935, 28);
            panel5.TabIndex = 16;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(758, 6);
            label13.Name = "label13";
            label13.Size = new Size(73, 17);
            label13.TabIndex = 0;
            label13.Text = "ErrAutoRes";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(716, 6);
            label14.Name = "label14";
            label14.Size = new Size(36, 17);
            label14.TabIndex = 0;
            label14.Text = "state";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(659, 6);
            label15.Name = "label15";
            label15.Size = new Size(30, 17);
            label15.TabIndex = 0;
            label15.Text = "ETA";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(538, 6);
            label21.Name = "label21";
            label21.Size = new Size(56, 17);
            label21.TabIndex = 0;
            label21.Text = "Average";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new Point(460, 6);
            label22.Name = "label22";
            label22.Size = new Size(50, 17);
            label22.TabIndex = 0;
            label22.Text = "Complt";
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Location = new Point(406, 6);
            label23.Name = "label23";
            label23.Size = new Size(42, 17);
            label23.TabIndex = 0;
            label23.Text = "ToFile";
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Location = new Point(339, 6);
            label24.Name = "label24";
            label24.Size = new Size(57, 17);
            label24.TabIndex = 0;
            label24.Text = "FromFile";
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Location = new Point(237, 6);
            label25.Name = "label25";
            label25.Size = new Size(92, 17);
            label25.TabIndex = 0;
            label25.Text = "CreatFileCount";
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Location = new Point(4, 6);
            label26.Name = "label26";
            label26.Size = new Size(89, 17);
            label26.TabIndex = 0;
            label26.Text = "Card ID name";
            // 
            // panel2
            // 
            panel2.Controls.Add(checkBox1);
            panel2.Controls.Add(listBox1);
            panel2.Controls.Add(button1);
            panel2.Controls.Add(comboBox2);
            panel2.Controls.Add(listBox2);
            panel2.Controls.Add(comboBox1);
            panel2.Controls.Add(linkLabel1);
            panel2.Controls.Add(linkLabel3);
            panel2.Controls.Add(linkLabel2);
            panel2.Controls.Add(textBox2);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(textBox1);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(label6);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(label8);
            panel2.Controls.Add(label5);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(label7);
            panel2.Location = new Point(6, 3);
            panel2.Name = "panel2";
            panel2.Size = new Size(935, 223);
            panel2.TabIndex = 2;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Checked = true;
            checkBox1.CheckState = CheckState.Checked;
            checkBox1.Location = new Point(480, 156);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(69, 21);
            checkBox1.TabIndex = 10;
            checkBox1.Text = "restore";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 17;
            listBox1.Location = new Point(3, 21);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(188, 157);
            listBox1.TabIndex = 2;
            // 
            // button1
            // 
            button1.Location = new Point(557, 152);
            button1.Name = "button1";
            button1.Size = new Size(210, 26);
            button1.TabIndex = 1;
            button1.Text = "arrange";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_ClickAsync;
            // 
            // comboBox2
            // 
            comboBox2.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "4096MB" });
            comboBox2.Location = new Point(557, 56);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(121, 25);
            comboBox2.TabIndex = 9;
            comboBox2.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
            // 
            // listBox2
            // 
            listBox2.FormattingEnabled = true;
            listBox2.ItemHeight = 17;
            listBox2.Location = new Point(230, 22);
            listBox2.Name = "listBox2";
            listBox2.Size = new Size(188, 157);
            listBox2.TabIndex = 2;
            // 
            // comboBox1
            // 
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(557, 87);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(121, 25);
            comboBox1.TabIndex = 9;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.LinkBehavior = LinkBehavior.HoverUnderline;
            linkLabel1.Location = new Point(197, 71);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(27, 17);
            linkLabel1.TabIndex = 3;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "-->";
            linkLabel1.LinkClicked += linkLabel1_LinkClicked;
            // 
            // linkLabel3
            // 
            linkLabel3.AutoSize = true;
            linkLabel3.LinkBehavior = LinkBehavior.HoverUnderline;
            linkLabel3.Location = new Point(770, 22);
            linkLabel3.Name = "linkLabel3";
            linkLabel3.Size = new Size(23, 17);
            linkLabel3.TabIndex = 8;
            linkLabel3.TabStop = true;
            linkLabel3.Text = ".....";
            linkLabel3.LinkClicked += linkLabel3_LinkClicked;
            // 
            // linkLabel2
            // 
            linkLabel2.AutoSize = true;
            linkLabel2.LinkBehavior = LinkBehavior.HoverUnderline;
            linkLabel2.Location = new Point(197, 110);
            linkLabel2.Name = "linkLabel2";
            linkLabel2.Size = new Size(27, 17);
            linkLabel2.TabIndex = 3;
            linkLabel2.TabStop = true;
            linkLabel2.Text = "<--";
            linkLabel2.LinkClicked += linkLabel2_LinkClicked;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(557, 122);
            textBox2.Name = "textBox2";
            textBox2.ReadOnly = true;
            textBox2.Size = new Size(121, 23);
            textBox2.TabIndex = 7;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(38, 1);
            label1.Name = "label1";
            label1.Size = new Size(47, 17);
            label1.TabIndex = 4;
            label1.Text = "CarList";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(557, 18);
            textBox1.Name = "textBox1";
            textBox1.ReadOnly = true;
            textBox1.Size = new Size(210, 23);
            textBox1.TabIndex = 7;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(462, 21);
            label3.Name = "label3";
            label3.Size = new Size(87, 17);
            label3.TabIndex = 4;
            label3.Text = "DataSavePath";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(487, 90);
            label6.Name = "label6";
            label6.Size = new Size(62, 17);
            label6.TabIndex = 4;
            label6.Text = "CreatSize";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(279, 2);
            label2.Name = "label2";
            label2.Size = new Size(72, 17);
            label2.TabIndex = 4;
            label2.Text = "PostCarList";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(457, 125);
            label8.Name = "label8";
            label8.Size = new Size(92, 17);
            label8.TabIndex = 4;
            label8.Text = "CreatFileCount";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(3, 204);
            label5.Name = "label5";
            label5.Size = new Size(21, 17);
            label5.TabIndex = 4;
            label5.Text = "ID";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(3, 183);
            label4.Name = "label4";
            label4.Size = new Size(110, 17);
            label4.TabIndex = 4;
            label4.Text = "commitmentAtxId";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(499, 59);
            label7.Name = "label7";
            label7.Size = new Size(50, 17);
            label7.TabIndex = 4;
            label7.Text = "FileSize";
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.AutoScroll = true;
            flowLayoutPanel1.Location = new Point(6, 254);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(935, 275);
            flowLayoutPanel1.TabIndex = 10;
            flowLayoutPanel1.Paint += flowLayoutPanel1_Paint;
            // 
            // richTextBox1
            // 
            richTextBox1.Location = new Point(0, 567);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.ReadOnly = true;
            richTextBox1.Size = new Size(944, 66);
            richTextBox1.TabIndex = 5;
            richTextBox1.Text = "";
            // 
            // button2
            // 
            button2.Location = new Point(732, 535);
            button2.Name = "button2";
            button2.Size = new Size(210, 26);
            button2.TabIndex = 1;
            button2.Text = "Start";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(panel6);
            tabPage2.Controls.Add(panel3);
            tabPage2.Controls.Add(checkBox3);
            tabPage2.Controls.Add(flowLayoutPanel2);
            tabPage2.Controls.Add(button5);
            tabPage2.Controls.Add(listBox3);
            tabPage2.Controls.Add(label19);
            tabPage2.Location = new Point(4, 26);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(944, 636);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Go-Spacemesh";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            panel6.Controls.Add(textBox6);
            panel6.Controls.Add(textBox5);
            panel6.Controls.Add(textBox4);
            panel6.Controls.Add(label28);
            panel6.Controls.Add(label27);
            panel6.Controls.Add(label20);
            panel6.Location = new Point(175, 0);
            panel6.Name = "panel6";
            panel6.Size = new Size(758, 28);
            panel6.TabIndex = 9;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(708, 3);
            textBox6.Multiline = true;
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(35, 23);
            textBox6.TabIndex = 13;
            textBox6.Text = "6";
            // 
            // textBox5
            // 
            textBox5.Location = new Point(603, 3);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(40, 23);
            textBox5.TabIndex = 14;
            textBox5.Text = "288";
            // 
            // textBox4
            // 
            textBox4.Location = new Point(83, 3);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(459, 23);
            textBox4.TabIndex = 12;
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.Location = new Point(650, 6);
            label28.Name = "label28";
            label28.Size = new Size(55, 17);
            label28.TabIndex = 9;
            label28.Text = "threads:";
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Location = new Point(548, 6);
            label27.Name = "label27";
            label27.Size = new Size(52, 17);
            label27.TabIndex = 10;
            label27.Text = "nonces:";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(14, 6);
            label20.Name = "label20";
            label20.Size = new Size(63, 17);
            label20.TabIndex = 11;
            label20.Text = "coinbase:";
            // 
            // panel3
            // 
            panel3.BackColor = SystemColors.ActiveBorder;
            panel3.Controls.Add(label39);
            panel3.Controls.Add(label34);
            panel3.Controls.Add(label38);
            panel3.Controls.Add(label35);
            panel3.Controls.Add(label37);
            panel3.Controls.Add(label36);
            panel3.Location = new Point(186, 31);
            panel3.Name = "panel3";
            panel3.Size = new Size(747, 34);
            panel3.TabIndex = 0;
            // 
            // label39
            // 
            label39.AutoSize = true;
            label39.Location = new Point(387, 9);
            label39.Name = "label39";
            label39.Size = new Size(31, 17);
            label39.TabIndex = 0;
            label39.Text = "Size";
            // 
            // label34
            // 
            label34.AutoSize = true;
            label34.Location = new Point(3, 9);
            label34.Name = "label34";
            label34.Size = new Size(0, 17);
            label34.TabIndex = 0;
            // 
            // label38
            // 
            label38.AutoSize = true;
            label38.Location = new Point(436, 9);
            label38.Name = "label38";
            label38.Size = new Size(33, 17);
            label38.TabIndex = 0;
            label38.Text = "Post";
            // 
            // label35
            // 
            label35.AutoSize = true;
            label35.Location = new Point(35, 9);
            label35.Name = "label35";
            label35.Size = new Size(62, 17);
            label35.TabIndex = 0;
            label35.Text = "Coinbase";
            // 
            // label37
            // 
            label37.AutoSize = true;
            label37.Location = new Point(485, 9);
            label37.Name = "label37";
            label37.Size = new Size(46, 17);
            label37.TabIndex = 0;
            label37.Text = "NiPost";
            // 
            // label36
            // 
            label36.AutoSize = true;
            label36.Location = new Point(537, 9);
            label36.Name = "label36";
            label36.Size = new Size(54, 17);
            label36.TabIndex = 0;
            label36.Text = "RunPort";
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.Checked = true;
            checkBox3.CheckState = CheckState.Checked;
            checkBox3.Location = new Point(10, 575);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new Size(92, 21);
            checkBox3.TabIndex = 7;
            checkBox3.Text = "SaveConfig";
            checkBox3.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel2
            // 
            flowLayoutPanel2.Location = new Point(186, 67);
            flowLayoutPanel2.Name = "flowLayoutPanel2";
            flowLayoutPanel2.Size = new Size(747, 558);
            flowLayoutPanel2.TabIndex = 4;
            // 
            // button5
            // 
            button5.Location = new Point(8, 602);
            button5.Name = "button5";
            button5.Size = new Size(165, 23);
            button5.TabIndex = 3;
            button5.Text = "RunAllNode";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // listBox3
            // 
            listBox3.ContextMenuStrip = contextMenuStrip1;
            listBox3.FormattingEnabled = true;
            listBox3.ItemHeight = 17;
            listBox3.Location = new Point(8, 31);
            listBox3.Name = "listBox3";
            listBox3.Size = new Size(165, 531);
            listBox3.TabIndex = 2;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.Items.AddRange(new ToolStripItem[] { addDiskDirToolStripMenuItem, removeDirToolStripMenuItem });
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(145, 48);
            contextMenuStrip1.Opening += contextMenuStrip1_Opening;
            // 
            // addDiskDirToolStripMenuItem
            // 
            addDiskDirToolStripMenuItem.Name = "addDiskDirToolStripMenuItem";
            addDiskDirToolStripMenuItem.Size = new Size(144, 22);
            addDiskDirToolStripMenuItem.Text = "Add Dir";
            addDiskDirToolStripMenuItem.Click += addDiskDirToolStripMenuItem_Click;
            // 
            // removeDirToolStripMenuItem
            // 
            removeDirToolStripMenuItem.Name = "removeDirToolStripMenuItem";
            removeDirToolStripMenuItem.Size = new Size(144, 22);
            removeDirToolStripMenuItem.Text = "Remove Dir";
            removeDirToolStripMenuItem.Click += removeDirToolStripMenuItem_Click;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(30, 11);
            label19.Name = "label19";
            label19.Size = new Size(96, 17);
            label19.TabIndex = 1;
            label19.Text = "Select Post DIR";
            // 
            // SpaceHelper
            // 
            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(949, 743);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            MaximizeBox = false;
            Name = "SpaceHelper";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "SpacemeshHelper";
            FormClosing += SpaceHelper_FormClosing;
            Load += SpaceHelper_Load;
            Shown += SpaceHelper_Shown;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            contextMenuStrip1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private Button button1;
        private LinkLabel linkLabel2;
        private LinkLabel linkLabel1;
        private ListBox listBox2;
        private ListBox listBox1;
        private Label label1;
        private Label label2;
        private RichTextBox richTextBox1;
        private Label label3;
        private Label label5;
        private Label label4;
        private TextBox textBox1;
        private LinkLabel linkLabel3;
        private ComboBox comboBox1;
        private Label label6;
        private ComboBox comboBox2;
        private Label label7;
        private Label label8;
        private TextBox textBox2;
        private FolderBrowserDialog folderBrowserDialog1;
        private FlowLayoutPanel flowLayoutPanel1;
        private Button button2;
        private Panel panel2;
        private Panel panel4;
        private Label label11;
        private Label label9;
        private Label label12;
        private TextBox textBox3;
        private LinkLabel linkLabel5;
        private LinkLabel linkLabel4;
        private Label label16;
        private Label label10;
        private Label label18;
        private Label label17;
        private CheckBox checkBox1;
        private CheckBox checkBox2;
        private Button button5;
        private ListBox listBox3;
        private Label label19;
        private FlowLayoutPanel flowLayoutPanel2;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem addDiskDirToolStripMenuItem;
        private ToolStripMenuItem removeDirToolStripMenuItem;
        private FolderBrowserDialog folderBrowserDialog2;
        private Panel panel3;
        private Label label39;
        private Label label34;
        private Label label38;
        private Label label35;
        private Label label37;
        private Label label36;
        private CheckBox checkBox3;
        private CheckBox checkBox4;
        private Panel panel5;
        private Label label13;
        private Label label14;
        private Label label15;
        private Label label21;
        private Label label22;
        private Label label23;
        private Label label24;
        private Label label25;
        private Label label26;
        private CheckBox checkBox5;
        private Panel panel6;
        private TextBox textBox6;
        private TextBox textBox5;
        private TextBox textBox4;
        private Label label28;
        private Label label27;
        private Label label20;
    }
}