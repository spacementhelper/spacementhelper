﻿namespace SpacemeshHelper
{
    partial class UC
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            panel6 = new Panel();
            label21 = new Label();
            label22 = new Label();
            label25 = new Label();
            label26 = new Label();
            label31 = new Label();
            label32 = new Label();
            label33 = new Label();
            label40 = new Label();
            label41 = new Label();
            label_copl = new Label();
            label_speed = new Label();
            label3 = new Label();
            button2 = new Button();
            checkBox1 = new CheckBox();
            pictureBox1 = new PictureBox();
            button1 = new Button();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            label2 = new Label();
            label1 = new Label();
            panel1.SuspendLayout();
            panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(panel6);
            panel1.Controls.Add(label_copl);
            panel1.Controls.Add(label_speed);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(checkBox1);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(textBox2);
            panel1.Controls.Add(textBox1);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(934, 24);
            panel1.TabIndex = 0;
            panel1.Paint += panel1_Paint;
            // 
            // panel6
            // 
            panel6.BackColor = Color.DarkGray;
            panel6.Controls.Add(label21);
            panel6.Controls.Add(label22);
            panel6.Controls.Add(label25);
            panel6.Controls.Add(label26);
            panel6.Controls.Add(label31);
            panel6.Controls.Add(label32);
            panel6.Controls.Add(label33);
            panel6.Controls.Add(label40);
            panel6.Controls.Add(label41);
            panel6.Location = new Point(0, 33);
            panel6.Name = "panel6";
            panel6.Size = new Size(0, 0);
            panel6.TabIndex = 14;
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(758, 6);
            label21.Name = "label21";
            label21.Size = new Size(73, 17);
            label21.TabIndex = 0;
            label21.Text = "ErrAutoRes";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new Point(716, 6);
            label22.Name = "label22";
            label22.Size = new Size(36, 17);
            label22.TabIndex = 0;
            label22.Text = "state";
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Location = new Point(659, 6);
            label25.Name = "label25";
            label25.Size = new Size(30, 17);
            label25.TabIndex = 0;
            label25.Text = "ETA";
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Location = new Point(570, 6);
            label26.Name = "label26";
            label26.Size = new Size(56, 17);
            label26.TabIndex = 0;
            label26.Text = "Average";
            // 
            // label31
            // 
            label31.AutoSize = true;
            label31.Location = new Point(494, 6);
            label31.Name = "label31";
            label31.Size = new Size(50, 17);
            label31.TabIndex = 0;
            label31.Text = "Complt";
            // 
            // label32
            // 
            label32.AutoSize = true;
            label32.Location = new Point(440, 6);
            label32.Name = "label32";
            label32.Size = new Size(42, 17);
            label32.TabIndex = 0;
            label32.Text = "ToFile";
            // 
            // label33
            // 
            label33.AutoSize = true;
            label33.Location = new Point(373, 6);
            label33.Name = "label33";
            label33.Size = new Size(57, 17);
            label33.TabIndex = 0;
            label33.Text = "FromFile";
            // 
            // label40
            // 
            label40.AutoSize = true;
            label40.Location = new Point(271, 6);
            label40.Name = "label40";
            label40.Size = new Size(92, 17);
            label40.TabIndex = 0;
            label40.Text = "CreatFileCount";
            // 
            // label41
            // 
            label41.AutoSize = true;
            label41.Location = new Point(4, 6);
            label41.Name = "label41";
            label41.Size = new Size(89, 17);
            label41.TabIndex = 0;
            label41.Text = "Card ID name";
            // 
            // label_copl
            // 
            label_copl.AutoSize = true;
            label_copl.Location = new Point(474, 4);
            label_copl.Name = "label_copl";
            label_copl.Size = new Size(15, 17);
            label_copl.TabIndex = 9;
            label_copl.Text = "0";
            // 
            // label_speed
            // 
            label_speed.AutoSize = true;
            label_speed.Location = new Point(534, 4);
            label_speed.Name = "label_speed";
            label_speed.Size = new Size(42, 17);
            label_speed.TabIndex = 9;
            label_speed.Text = "0KB/s";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(633, 4);
            label3.Name = "label3";
            label3.Size = new Size(73, 17);
            label3.TabIndex = 9;
            label3.Text = "00:00:00:00";
            // 
            // button2
            // 
            button2.Location = new Point(873, 0);
            button2.Name = "button2";
            button2.Size = new Size(58, 23);
            button2.TabIndex = 8;
            button2.Text = "Display";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Checked = true;
            checkBox1.CheckState = CheckState.Checked;
            checkBox1.Location = new Point(775, 6);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(15, 14);
            checkBox1.TabIndex = 7;
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            pictureBox1.InitialImage = null;
            pictureBox1.Location = new Point(717, 2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(36, 21);
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // button1
            // 
            button1.Location = new Point(809, 0);
            button1.Name = "button1";
            button1.Size = new Size(58, 23);
            button1.TabIndex = 1;
            button1.Text = "Stop";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(411, 1);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(39, 23);
            textBox2.TabIndex = 4;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(352, 1);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(39, 23);
            textBox1.TabIndex = 4;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(282, 6);
            label2.Name = "label2";
            label2.Size = new Size(15, 17);
            label2.TabIndex = 3;
            label2.Text = "0";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(4, 7);
            label1.Name = "label1";
            label1.Size = new Size(76, 17);
            label1.TabIndex = 2;
            label1.Text = "0--RTX3090";
            // 
            // UC
            // 
            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panel1);
            Name = "UC";
            Size = new Size(934, 24);
            Load += UC_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Label label1;
        private Label label2;
        private TextBox textBox2;
        private TextBox textBox1;
        private PictureBox pictureBox1;
        private Button button1;
        private CheckBox checkBox1;
        private Button button2;
        private Label label3;
        private Label label_speed;
        private Label label_copl;
        private Panel panel6;
        private Label label21;
        private Label label22;
        private Label label25;
        private Label label26;
        private Label label31;
        private Label label32;
        private Label label33;
        private Label label40;
        private Label label41;
    }
}
