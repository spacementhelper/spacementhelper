运行程序  先刷新版本 更新为最新版本，如何你的网络不能通过程序更新，请自行下载文件后解压到对应的目录 。目录格式为POST_0.9.4   （0.9.4为版本号）和 GO-SPACE_1.1.4 （1.1.4 为版本号）
运行程序前，你要先运行一个Spacemesh 节点。节点正常运行后启动本程序 在SpaceMesh节点IP内填入你运行节点的IP与端口，
一、多显卡P盘。
1 。从显卡列表中选择你要工作的显卡到P盘显卡列表 。
2。选择你要生成文件的目录，
3。选择你要生成文件的总大小。
4。点击部署多卡P盘
在下方列出每张显卡P多少文件，你也可以自行更改开始文件与结束文件。让性能高的显卡创建更多数量的文件。性能低的显卡创建更少的文件 。以实现完成时间基本一致。
如何节点没有问题，那么CommitmetAtxID与ID将会正常获取并计算出来 。如果没有获取到CommitmetAtxID那么你应该检查你的SpaceMesh主程序是否正常运行。直到点击部署多卡能正常获取到CommitmetAtxID。
当正常获取到ID后。就可以点击开始任务进行批量P盘了。
二、挂盘。
将选项卡切换到Go-spacesh挂盘。

1。填入你的spacemesh钱包地址。 nonces与线程请根据你的配置来修改。
2。右键点击挂盘目录下方列表，选择添加目录，添加你已P好的目录。可以无限添加多个目录。可以添加非本软件创建的文件目录，添加完成后，点击挂载所有目录。程序会自动将你添加的目录分别运行不同的节点来批量挂载。
3。你可以通过下方的列表查看文件挂载的详细信息。以及每个节点的同步状态。
 
自动： 当你勾选自动运行多卡P盘后，你将程序加入开机运行，当电脑重启后。会自动运行上次未完成的P盘任务。
          当你勾选自动运行GO-space挂盘后，程序运行时，会自动载入上次所有挂盘目录 自动运行挂盘。

	

"To run the program, first refresh it to the latest version. If your network cannot update the program, please download the files manually and extract them to the corresponding directory. The directory format should be POST_0.9.4 (0.9.4 is the version number) and GO-SPACE_1.1.4 (1.1.4 is the version number).

Before running the program, you need to start a Spacemesh node. After the node is running correctly, launch this program and enter the IP and port of your running node in the Spacemesh node IP field.

I. Multi-GPU P-Drive.

Choose the GPU you want to work with from the list of graphics cards and add it to the P-Drive GPU list.
Select the directory where you want to generate files.
Choose the total size of the files you want to generate.
Click 'Deploy Multi-GPU P-Drive.'
Below, list how many files will be P'ed for each GPU. You can also manually change the start and end files to allow high-performance GPUs to create more files and low-performance GPUs to create fewer files to achieve roughly the same completion time.

If there are no issues with the node, CommitmetAtxID and ID will be retrieved and calculated normally. If CommitmetAtxID is not obtained, you should check if your Spacemesh main program is running correctly until you can successfully retrieve CommitmetAtxID by clicking 'Deploy Multi-GPU.'

Once you've obtained the ID normally, you can click 'Start' 

II. Go-Spacemesh
Switch to the Go-Spacemesh Disk Mounting tab.

Enter your Spacemesh wallet address. Modify nonces and threads based on your configuration.

Right-click on the list below the mounting directory, select 'Add Directory,' and add the directories you've already P'ed. You can add an unlimited number of directories. You can also add directories created by other software. After adding, click 'Mount All Directories.' The program will automatically run different nodes for each directory to batch mount.

You can view detailed information about file mounting in the list below, as well as the synchronization status of each node.

Automatic: When you check 'Automatically run Multi-GPU ,' the program will be added to startup. When your computer restarts, it will automatically resume the last unfinished task.

When you check 'Automatically run GO-Space ,' the program will automatically load all mounted directories from the last run and automatically run the mounting process."